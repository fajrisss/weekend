const testimonial =[
  {
    "id": "dv2o78l11m",
    "testimony": "I couldn't have asked for more than this. I wish I would have thought of it first. This is simply unbelievable!",
    "by": "Arron"
  },
  {
    "id": "903lf1itgt",
    "testimony": "Wow what great service, I love it! Without WEEKEND, we would have gone by now. You guys rock!",
    "by": "Kelsey"
  },
  {
    "id": "nj645u5e4a",
    "testimony": "I wish I would have thought of it first.",
    "by": "Steven"
  },
  {
    "id": "4rjtcb1wh0",
    "testimony": "Fantastic, I'm totally blown away by WEEKEND",
    "by": "Charley"
  },
  {
    "id": "qvt7jp8p3d",
    "testimony": "This is unbelievable. After using WEEKEND my business skyrocketed!",
    "by": "Vanessa"
  }
]



export default testimonial;