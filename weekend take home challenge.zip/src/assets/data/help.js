const help = [
  {
    "id": "dbh6fghjgj",
    "title": "Start quickly with simple steps",
    "slug": "start-quickly-with-simple-steps",
    "image": "https://challenge.fe.weekendinc.com/dbh6fghjgj.jpg"
  },
  {
    "id": "lgmd6ielxi",
    "title": "Run smoothly at vero eos et accusamus",
    "slug": "run-smoothly-at-vero-eos-et-accusamus",
    "image": "https://challenge.fe.weekendinc.com/lgmd6ielxi.jpg"
  },
  {
    "id": "qlrl8c8xqg",
    "title": "Denounce with righteous indignation",
    "slug": "denounce-with-righteous-indignation",
    "image": "https://challenge.fe.weekendinc.com/qlrl8c8xqg.jpg"
  }
]

export default help;